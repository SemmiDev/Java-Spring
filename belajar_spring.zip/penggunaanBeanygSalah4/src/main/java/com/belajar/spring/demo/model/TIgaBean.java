package com.belajar.spring.demo.model;

public class TIgaBean {
    private SatuBean satuBean;

    public SatuBean getSatuBean() {
        return satuBean;
    }

    public void setSatuBean(SatuBean satuBean) {
        this.satuBean = satuBean;
    }

    public TIgaBean(SatuBean satuBean) {
        this.satuBean = satuBean;
    }
}
