package com.belajar.spring.demo.model;

public class DuaBean {
    private TIgaBean tIgaBean;

    public TIgaBean gettIgaBean() {
        return tIgaBean;
    }

    public void settIgaBean(TIgaBean tIgaBean) {
        this.tIgaBean = tIgaBean;
    }

    public DuaBean(TIgaBean tIgaBean) {
        this.tIgaBean = tIgaBean;
    }
}
