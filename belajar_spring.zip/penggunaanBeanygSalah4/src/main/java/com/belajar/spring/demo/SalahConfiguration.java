package com.belajar.spring.demo;

import com.belajar.spring.demo.model.DuaBean;
import com.belajar.spring.demo.model.SatuBean;
import com.belajar.spring.demo.model.TIgaBean;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SalahConfiguration {
    @Bean
    public SatuBean CreatesatuBean(DuaBean duaBean){
        return new SatuBean(duaBean);
    }
    @Bean
    public DuaBean CreateduaBean(TIgaBean tIgaBean){
        return new DuaBean(tIgaBean);
    }
    @Bean
    public TIgaBean CreatetIgaBean(SatuBean satuBean){
        return  new TIgaBean(satuBean);
    }
}
