package com.belajar.spring.demo.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class BahanScope {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public BahanScope(String value) {
        this.value = value;
    }

}
