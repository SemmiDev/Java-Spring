package com.belajar.spring.demo.service;

import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
public class DatabaseSeevice {

    // anotasi akan memanggil method ini ketika database ini dibuat
    @PostConstruct
    public void openConnection(){
        System.out.println("open connection");
    }

    // anotasi ini akan dipanggil di akhir kali database ini
    @PreDestroy
    public void closeConnection(){
        System.out.println("close connection");
    }
}
