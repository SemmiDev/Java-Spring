package com.belajar.spring.demo.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Participants {

    private ParticipantFilter filter;
    // didalam constructor kita membutuhkan dependenci injection yg dibutuhkan spring
    @Autowired
    public Participants(ParticipantFilter filter) {
        this.filter = filter;
    }

    public String name(String name){
        return filter.filtering(name);
    }
}

