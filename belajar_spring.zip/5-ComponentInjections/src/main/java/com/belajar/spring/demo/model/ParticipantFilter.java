package com.belajar.spring.demo.model;

import org.springframework.stereotype.Component;

@Component
public class ParticipantFilter {
    public String filtering(String value){
        return value.toUpperCase();
    }
}
