package com.belajar.spring.demo;
import com.belajar.spring.demo.model.Participants;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;


@SpringBootApplication
public class BelajarSpringApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(BelajarSpringApplication.class, args);
		Participants participants = context.getBean(Participants.class);

		System.out.println("Nama  : " + participants.name("Sammi"));
	}
}