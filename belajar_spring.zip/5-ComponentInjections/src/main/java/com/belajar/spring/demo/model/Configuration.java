//package com.belajar.spring.demo.model;
//
//import org.springframework.context.annotation.Bean;
//
//public class Configuration {
//    @Bean
//    public Participants participants(){
//        return new Participants();
//    }
//}
