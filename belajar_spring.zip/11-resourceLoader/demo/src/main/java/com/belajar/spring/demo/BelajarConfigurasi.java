package com.belajar.spring.demo;

import com.belajar.spring.demo.model.*;
import com.belajar.spring.demo.service.DatabaseConfig;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.util.ResourceBundle;
import java.util.UUID;

@SpringBootApplication
public class BelajarConfigurasi {

}
