package com.belajar.spring.demo.model;

import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Scanner;

@Component
public class FIleBean implements ResourceLoaderAware {
    private ResourceLoader loader;

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.loader = resourceLoader;
    }

    public void printInfo() throws IOException {
        Resource resource =  loader.getResource("classpath:/resources/info.txt");
        Resource resource1 = loader.getResource("classpath:/resources/siswa.txt");

        Scanner scanner = new Scanner(resource.getInputStream());
        Scanner scanner1 = new Scanner(resource1.getInputStream());

        while(scanner.hasNextLine()){
            String line = scanner.nextLine();
            System.out.println(line);
        }
        while (scanner1.hasNextLine()){
            String line = scanner1.nextLine();
            System.out.println(line);
        }
        scanner.close();
    }
}
