package com.belajar.spring.demo.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class SayHello implements MessageSourceAware {
    private SayHelloFilter filter;
    private SayHelloFilter filter2;
    private MessageSource messageSource;

    @Autowired // harus, bahwa dalam ocnstructor kita buth injeksi yg perlu dimasukkan
    public SayHello(SayHelloFilter filter) {
        this.filter = filter;
    }


    public String hello(String name){
        return filter.filter(messageSource.getMessage("adit",null, Locale.getDefault()) + " " + name);
    }
    public String hello2(String name){
            return filter.filter(messageSource.getMessage("sam",null, Locale.getDefault()) + " " + name);
    }
    public String hello3(String name){
        return filter.filter(messageSource.getMessage("ayatullah",null, Locale.getDefault()) + " " + name);
    }
    public String hello4(String name){
        return filter.filter(messageSource.getMessage("gusnur",null, Locale.getDefault()) + " " + name);
    }
    public String hello5(String name){
        return filter.filter(messageSource.getMessage("dandi",null, Locale.getDefault()) + " " + name);
    }
    public String hello6(String name){
        return filter.filter(messageSource.getMessage("rauf",null, Locale.getDefault()) + " " + name);
    }

    @Override
    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}
