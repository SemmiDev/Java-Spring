public class BelajarSpringApplication{
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(BElajarConfigurasi.class, args);
		
		// bagian bean
		// bean merupakan object
		// cara membuat bean
		// buat package model
		
		// untuk manggil bean tadi
		DataBean data = context.getBean(DataBean.class);
		System.out.println(data.getValue);
		// sampai disni jalankan di terminal mvn spring-boot:run

		// untuk menjalankan yg ini, komentari dulu bagian atas itu
		SampleBean data = context.getBean(SampleBean.class);
		System.out.println(data.getDataBean().getValue());
		// run di terminal
	}
}