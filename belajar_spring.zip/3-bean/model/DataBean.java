public class DataBean{
	private String value;

	public DataBean(String value){
		this.value = value;
	}

	// getter and setter
	public String getValue(){
		return value;
	}

	public void setValue(String value){
		this.value = value;
	}
}