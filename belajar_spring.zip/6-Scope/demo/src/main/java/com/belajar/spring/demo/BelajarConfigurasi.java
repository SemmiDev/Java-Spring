package com.belajar.spring.demo;

import com.belajar.spring.demo.model.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

import java.util.UUID;

@SpringBootApplication
public class BelajarConfigurasi {
    @Bean(name = "sam")
    public DataBean createDataBean(){
        DataBean bean = new DataBean("Sammi Aldhi Yanto",19,"XII MIPA 1");
        return bean;
    }

    @Bean(name = "ferdi")
    public DataBean createDataBean2(){
        DataBean bean = new DataBean("Ferdi Syukroni",19,"XII MIPA 4");
        return bean;
    }


    // injections
    @Bean
    public SampleBean createSampleBean(@Qualifier("sam") DataBean dataBean){
        SampleBean bean = new SampleBean(dataBean);
        return bean;
    }

    @Bean
    public OtherBean createOtherBean(@Qualifier("ferdi") DataBean dataBean, SampleBean sampleBean) {
        OtherBean otherBean = new OtherBean(dataBean,sampleBean);
        return otherBean;
    }




















    // ini untuk bagian scope
    // bean nya akan sama saja
    @Bean(name = "scope")
    public BahanScope createBahanScope(){
        String random = UUID.randomUUID().toString();
        BahanScope bahanScope = new BahanScope(random);
        return bahanScope;
    }

    // ini beda
    // keyword prototype = akan dibuat baru objek nya
    // keywork singelton = hanya memmbuat saja objek saja
    @Bean(name = "scopee")
    @Scope("prototype")
    public BahanScope createBahanScope2(){
        String random = UUID.randomUUID().toString();
        BahanScope bahanScope = new BahanScope(random);
        return bahanScope;
    }

    @Bean
    public SampleScope createSampleBean2(@Qualifier("scopee") BahanScope bahanScope){
       SampleScope sampleScope = new SampleScope(bahanScope);
        return sampleScope;
    }

}
