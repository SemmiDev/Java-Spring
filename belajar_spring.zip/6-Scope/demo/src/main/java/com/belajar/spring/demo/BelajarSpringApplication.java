package com.belajar.spring.demo;

import com.belajar.spring.demo.model.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import javax.xml.crypto.Data;

@SpringBootApplication
public class BelajarSpringApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(BelajarSpringApplication.class, args);


//		OtherBean otherBean = context.getBean(OtherBean.class);
//		// ferdi
//		System.out.println(otherBean.getDataBean().getData());
//		System.out.println("\n");
//		// sammi
//		System.out.println(otherBean.getSampleBean().getDataBean().getData());















		// scope
		BahanScope bahanScope1 = context.getBean("scope",BahanScope.class);
		BahanScope bahanScope2 = context.getBean("scope",BahanScope.class);
		BahanScope bahanScope3 = context.getBean("scope",BahanScope.class);

		// akan membuat sebuah objek saja
		System.out.println("ini satu objek");
		System.out.println(bahanScope1.getValue());
		System.out.println(bahanScope2.getValue());
		System.out.println(bahanScope3.getValue());



		BahanScope bahanScope11 = context.getBean("scopee",BahanScope.class);
		BahanScope bahanScope22 = context.getBean("scopee",BahanScope.class);
		BahanScope bahanScope33 = context.getBean("scopee",BahanScope.class);

		// membuat objek baru
		System.out.println("ini satu objek baru");
		BahanScope bahanScope4 = context.getBean("scopee",BahanScope.class);
		System.out.println(bahanScope11.getValue());
		System.out.println(bahanScope22.getValue());
		System.out.println(bahanScope33.getValue());

		// saat kita memanggil sample bean, maka dia juga akan ikut berubah
		System.out.println("ini beda objek, hasil injeksi ke sampleScope");
		SampleScope sampleScope = context.getBean(SampleScope.class);
		System.out.println(sampleScope.getBahanScope().getValue());

	}
}
