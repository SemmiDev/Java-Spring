
// disini kita membuat bean2
@SpringBootApplication
public class BelajarConfigurasi{

	// untuk menandai bahwa ini adalah sebuah bean 
	// buat anotasi bean

	@Bean(name = "sam")
	public DataBean createDataBean(){
		DataBean bean = new DataBean("Sammi");
		return bean;

	@Bean(name = "dev")
	public DataBean createDataBean(){
		DataBean bean = new DataBean("Dev");
		return bean;



		// inject
		@Bean
		public SampleBean createSampleBean(@Qualifier("sam") DataBean dataBean){
			SampleBean bean = new SampleBean(DataBean dataBean);
			return bean;   
		} 
	}
}