public class SampleBean{
	private DataBean dataBean;
	// constructor
	public SimpleBean(DataBean dataBean){
		this.dataBean = dataBean;
	}

		public String getDataBean(){
		return dataBean;
	}

	public void setDataBean(String dataBean){
		this.dataBean = dataBean;
	}
}