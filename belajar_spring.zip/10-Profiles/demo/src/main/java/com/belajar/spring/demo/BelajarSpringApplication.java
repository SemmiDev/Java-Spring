package com.belajar.spring.demo;

import com.belajar.spring.demo.model.*;
import com.belajar.spring.demo.service.DatabaseConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import javax.xml.crypto.Data;

@SpringBootApplication
public class BelajarSpringApplication {

	public static void main(String[] args) {

		// Aware digunakan untuk memanggil applicationcontext ini di beans lain.

		// ini yg akan di running // profduction ataupun development
		System.setProperty("spring.profiles.active","production");
		ApplicationContext context = SpringApplication.run(BelajarSpringApplication.class, args);

		DatabaseConfig databaseConfig = context.getBean(DatabaseConfig.class);
		System.out.println(databaseConfig.getValue());


//		OtherBean otherBean = context.getBean(OtherBean.class);
//		// ferdi
//		System.out.println(otherBean.getDataBean().getData());
//		System.out.println("\n");
//		// sammi
//		System.out.println(otherBean.getSampleBean().getDataBean().getData());






	}
}
