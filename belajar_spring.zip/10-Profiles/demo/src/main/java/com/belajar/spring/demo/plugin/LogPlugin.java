package com.belajar.spring.demo.plugin;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.stereotype.Component;

@Component
public class LogPlugin extends InstantiationAwareBeanPostProcessorAdapter {
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        // setiap bean sudah dibuat maka akan kita tmpilkan ini :
        System.out.println("telah dbuat bean dengan nama " + beanName + ", dengan tipe bean getName");
        return bean;

    }
}
