package com.belajar.spring.demo.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class DataBean {
    private String name;
    private int umur;
    private String kelas;

    public DataBean(String name, int umur, String kelas) {
        this.name = name;
        this.umur = umur;
        this.kelas = kelas;
    }

    public String getData() {
        return  "Name   : " + this.name +
                "\nUmur  : " + this.umur +
                "\nKelas : " + this.kelas;
    }

    public void setData(String name, int umur) {
        this.name = name;
        this.umur = umur;
        this.kelas = kelas;
    }
}
