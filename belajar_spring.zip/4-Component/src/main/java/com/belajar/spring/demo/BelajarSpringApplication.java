package com.belajar.spring.demo;

import com.belajar.spring.demo.model.Participant2;
import com.belajar.spring.demo.model.Participants;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;


@SpringBootApplication
public class BelajarSpringApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(BelajarSpringApplication.class, args);
		Participants participants = context.getBean(Participants.class);
		System.out.println("Nama  : " + participants.name("Sammi"));
		System.out.println("Kelas : " + participants.kelas("XII MIPA 1"));
		System.out.println("Umur  : " + participants.age(19));

		Participant2 participant2 = context.getBean(Participant2.class);
		System.out.println(participant2.sayHello("Sam"));
	}
}