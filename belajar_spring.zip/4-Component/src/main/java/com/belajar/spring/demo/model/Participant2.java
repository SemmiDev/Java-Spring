package com.belajar.spring.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Participant2{
    public String sayHello(String name){
        return "hello " + name;
    }
}

