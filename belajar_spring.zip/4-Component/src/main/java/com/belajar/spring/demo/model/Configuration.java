package com.belajar.spring.demo.model;

import org.springframework.context.annotation.Bean;

public class Configuration {
    @Bean
    public Participants participants1(){
        return new Participants();
    }
    @Bean
    public Participant2 sayHello(){
        return new Participant2();
    }
}
