package com.belajar.spring.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Participants {
    public String name(String name){
        return name;
    }

    public String kelas(String kelas){
        return kelas;
    }

    public int age(int age){
        return age;
    }
}

