package com.belajar.spring.demo.model;

public class SampleScope {
    private BahanScope bahanScope;

    public SampleScope(BahanScope bahanScope) {
        this.bahanScope = bahanScope;
    }

    public BahanScope getBahanScope() {
        return bahanScope;
    }

    public void setBahanScope(BahanScope bahanScope) {
        this.bahanScope = bahanScope;
    }
}
