package com.belajar.spring.demo.model;

public class BahanScope {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public BahanScope(String value) {
        this.value = value;
    }
}
