package com.belajar.spring.demo.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// dengan menggunakan annotation component, maka akan secara otomatis dibuatkan sebuah bean
// dan kita tidak usah membuat bean untuk ini di belajarCOnfigurasi
@Component
public class SayHello {

    private SayHelloFilter filter;
    @Autowired // harus, bahwa dalam ocnstructor kita buth injeksi yg perlu dimasukkan
    public SayHello(SayHelloFilter filter) {
        this.filter = filter;
    }


    public String hello(String name){
        return filter.filter("hello " + name);
    }
}
