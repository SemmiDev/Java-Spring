package com.belajar.spring.demo;

import com.belajar.spring.demo.model.DataBean;
import com.belajar.spring.demo.model.OtherBean;
import com.belajar.spring.demo.model.SampleBean;
import com.belajar.spring.demo.model.SayHello;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class BelajarSpringApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(BelajarSpringApplication.class, args);
//		DataBean data = context.getBean(DataBean.class);
//		System.out.println("Name  		 : " + data.getValue());


//		SampleBean data = context.getBean(SampleBean.class);
//		System.out.println(data.getDataBean().getValue());


		OtherBean otherBean = context.getBean(OtherBean.class);
		// ferdi
		System.out.println(otherBean.getDataBean().getData());
		System.out.println("\n");
		// sammi
		System.out.println(otherBean.getSampleBean().getDataBean().getData());


//		SayHello hello = context.getBean(SayHello.class);
//		String response = hello.hello("Sam");
//		System.out.println(response);

	}
}
